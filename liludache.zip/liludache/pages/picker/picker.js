var util = require('../../utils/util.js')
var now_dt = new Date();
var now_date = util.formatDate(now_dt)
var now_time = util.formatHour_min(now_dt)
Page({
  data: {
    array: ['上海','无锡'],
    index_from: 0,
    index_to: 1,
    time_start: now_time,
    date_start: now_date,
    date : now_date,
    time : now_time,
    loading: false,
  },
  bindPickerChange_from: function(e) {
    console.log('picker发送选择改变，携带值为', e.detail.value,e)
    this.setData({
      index_from: e.detail.value
    })
  },
  bindPickerChange_to: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value, e)
    this.setData({
      index_to: e.detail.value
    })
  },
  bindDateChange: function(e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    console.log(now_date === e.detail.value)
    this.setData({
      date: e.detail.value
    })
    if (now_date === e.detail.value){
      this.setData({
        time_start: util.formatHour_min(new Date())
      })
    }
    else{
      this.setData({
        time_start: '00:00'
      })
    }
  },
  bindTimeChange: function(e) {
    this.setData({
      time: e.detail.value
    })
  },
  setLoading: function(e) {

    // body...
  }
})